import React from 'react';

class AgendaCard extends React.Component {
    // Tips formatting: CTRL + A, CTRL + K + F
    render() {
        return (
            <div id="agendaCard">
                <hr></hr>
                <h3>Agenda Title</h3>
                <p>15 April 2021 | 15.00</p>
                <p>Membahas kick-off project terbaru, KamiSabi.com</p>
            </div>
        );
    }
}

export default AgendaCard;