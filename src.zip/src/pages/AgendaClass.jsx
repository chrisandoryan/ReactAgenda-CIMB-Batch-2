import React from 'react';
import AgendaCard from '../components/AgendaCard';
import Header from '../components/Header';

class AgendaClass extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <Header />
                <div id="addAgendaForm">
                    <h2>Add New Agenda</h2>
                    <form>
                        <div>
                            <input type="text" placeholder="What do you want to do?"></input>
                        </div>
                        <div>
                            <textarea></textarea>
                        </div>
                        <div>
                            <input type="datetime" name="" id="" />
                        </div>
                        <button>Submit</button>
                    </form>
                </div>
                <div id="showAgenda">
                    <h2>Your Agenda</h2>
                    <AgendaCard />
                    <AgendaCard />
                    <AgendaCard />
                    <AgendaCard />
                </div>
            </div>
        );
    }
}

// Agar class bisa digunakan di .js lain
export default AgendaClass;